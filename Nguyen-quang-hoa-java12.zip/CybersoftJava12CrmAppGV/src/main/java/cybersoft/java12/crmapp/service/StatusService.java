package cybersoft.java12.crmapp.service;

import java.sql.SQLException;
import java.util.List;

import cybersoft.java12.crmapp.dao.StatusDao;
import cybersoft.java12.crmapp.dto.StatusCreateDto;
import cybersoft.java12.crmapp.dto.StatusUpdateDto;
import cybersoft.java12.crmapp.model.Status;

public class StatusService {
	private StatusDao dao;
	
	public StatusService() {
		dao = new StatusDao();
	}
	
	public void add(StatusCreateDto dto) {
		try {
			dao.add(dto);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

	public List<Status> findAll() {
		List<Status> status = null;
		status = dao.findAll();
		return status;
	}

	public void delete(int statusId) {
		dao.delete(statusId);
	}

	public List<StatusUpdateDto> findById(int statusIdUpdate) {
		List<StatusUpdateDto> dto = null;
		try {
			dto = dao.findById(statusIdUpdate);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dto;
	}

	public void update(StatusUpdateDto dtoUpdate) {
		try {
			dao.update(dtoUpdate);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}

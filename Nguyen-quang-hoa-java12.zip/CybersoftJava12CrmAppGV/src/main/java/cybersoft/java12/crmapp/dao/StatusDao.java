package cybersoft.java12.crmapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import cybersoft.java12.crmapp.dbconnection.MySqlConnection;
import cybersoft.java12.crmapp.dto.StatusCreateDto;
import cybersoft.java12.crmapp.dto.StatusUpdateDto;
import cybersoft.java12.crmapp.model.Status;

public class StatusDao {

	public void add(StatusCreateDto dto) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = "INSERT INTO status(name, description) VALUES(?,?)";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setNString(1, dto.getName());
			statement.setNString(2, dto.getDescription());
			statement.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}

	public List<Status> findAll() {
		List<Status> statuses = new LinkedList<Status>();
		Connection connection = MySqlConnection.getConnection();
		String query = " SELECT id, name , description FROM status ";
		
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Status status = new Status();
				status.setId(resultSet.getInt("id"));
				status.setName(resultSet.getString("name"));
				status.setDescription(resultSet.getString("description"));
				
				statuses.add(status);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return statuses;
	}

	public void delete(int statusId) {
		Connection connection = MySqlConnection.getConnection();
		String query = "DELETE FROM status WHERE id = ?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, statusId);
			statement.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	public List<StatusUpdateDto> findById(int statusIdUpdate) throws SQLException {
		List<StatusUpdateDto> dtos = new LinkedList<StatusUpdateDto>();
		Connection connection = MySqlConnection.getConnection();
		String query = "SELECT id, name, description FROM status WHERE id = ?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, statusIdUpdate);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				StatusUpdateDto dto;
				int id = resultSet.getInt("id");
				String name = resultSet.getString("name");
				String description = resultSet.getString("description");
				
				dto = new StatusUpdateDto(id, name, description);
				dtos.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return dtos;
	}

	public void update(StatusUpdateDto dtoUpdate) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = "UPDATE status SET name = ?, description = ? WHERE id = ? ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setNString(1, dtoUpdate.getName());
			statement.setNString(2, dtoUpdate.getDescription());
			statement.setInt(3, dtoUpdate.getId());
			statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}

}

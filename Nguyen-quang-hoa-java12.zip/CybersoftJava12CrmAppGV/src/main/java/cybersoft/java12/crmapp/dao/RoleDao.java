package cybersoft.java12.crmapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import cybersoft.java12.crmapp.dbconnection.MySqlConnection;
import cybersoft.java12.crmapp.dto.RoleCreateDto;
import cybersoft.java12.crmapp.dto.RoleUpdateDto;
import cybersoft.java12.crmapp.model.Role;

public class RoleDao {

	public List<Role> findAll() throws SQLException {
		List<Role> roles = new LinkedList<Role>();
		
		Connection connection = MySqlConnection.getConnection();
		String query = "SELECT id,name , description FROM role ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultset = statement.executeQuery();
			while( resultset.next() ) {
				Role role = new Role();
				role.setId(resultset.getInt("id"));
				role.setName(resultset.getString("name"));
				role.setDescription(resultset.getString("description"));
				roles.add(role);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return roles;
	}

	public void add(RoleCreateDto dto) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = "INSERT INTO role(name, description) VALUES(?,?)";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setNString(1, dto.getName());
			statement.setNString(2, dto.getDescription());
			statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		
	}

	public void delete(int roleId) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = "DELETE FROM role WHERE id = ? ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, roleId);
			statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}

	public void update(RoleUpdateDto dto) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = "UPDATE role SET name = ?, description = ? WHERE id = ? ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setNString(1, dto.getName());
			statement.setNString(2, dto.getDescription());
			statement.setInt(3, dto.getId());
			statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}

	public List<Role> findById(int roleIdUpdate) throws SQLException {
		List<Role> roles = new ArrayList<Role>();
		Connection connection = MySqlConnection.getConnection();
		String query = "SELECT id, name , description FROM role WHERE id = ?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, roleIdUpdate);
			ResultSet resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				Role role = new Role();
				role.setName(resultSet.getString("name"));
				role.setDescription(resultSet.getString("description"));
				role.setId(resultSet.getInt("id"));
				
				roles.add(role);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return roles;
	}

}

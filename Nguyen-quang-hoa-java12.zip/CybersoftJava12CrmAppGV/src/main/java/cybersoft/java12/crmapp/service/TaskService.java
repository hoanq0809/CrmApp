package cybersoft.java12.crmapp.service;

import java.sql.SQLException;
import java.util.List;

import cybersoft.java12.crmapp.dao.TaskDao;
import cybersoft.java12.crmapp.dto.TaskCreateDto;
import cybersoft.java12.crmapp.dto.TaskUpdateDto;
import cybersoft.java12.crmapp.model.Project;
import cybersoft.java12.crmapp.model.Status;
import cybersoft.java12.crmapp.model.Task;
import cybersoft.java12.crmapp.model.User;

public class TaskService {
	
	TaskDao dao;
	
	public TaskService() {
		dao = new TaskDao();
	}

	public List<Project> findProject() {
		List<Project> projects = null;
		try {
			projects = dao.findProjects();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return projects;
	}

	public List<User> findUser() {
		List<User> users = null;
		try {
			users = dao.findUser();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
	}

	public void add(TaskCreateDto dto) {
		try {
			dao.add(dto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public List<Status> findStatus() {
		List<Status> status = null;
		try {
			status = dao.findStatus();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return status;
	}

	public List<Task> findAll() {
		List<Task> tasks = null;
		try {
			tasks = dao.findAll();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tasks;
	}

	public void delete(int taskId) {
		try {
			dao.delete(taskId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	public List<TaskUpdateDto> findById(int taskUpdateId) {
		List<TaskUpdateDto> dtos =  null;
		try {
			dtos = dao.findById(taskUpdateId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dtos;
		
	}

	public void update(TaskUpdateDto dtoUpdate) {
		try {
			dao.update(dtoUpdate);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}




}

package cybersoft.java12.crmapp.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cybersoft.java12.crmapp.dto.ProjectCreateDto;
import cybersoft.java12.crmapp.dto.ProjectStaffCreateDto;
import cybersoft.java12.crmapp.dto.ProjectUpdateDto;
import cybersoft.java12.crmapp.model.Project;
import cybersoft.java12.crmapp.model.ProjectUser;
import cybersoft.java12.crmapp.model.User;
import cybersoft.java12.crmapp.service.ProjectService;
import cybersoft.java12.crmapp.util.JspConst;
import cybersoft.java12.crmapp.util.UrlConst;

@WebServlet(name = "projectServlet", urlPatterns = {
		UrlConst.PROJECT_DASHBOARD,
		UrlConst.PROJECT_MANAGE,
		UrlConst.PROJECT_ADD,
		UrlConst.PROJECT_UPDATE,
		UrlConst.PROJECT_DELETE,
		UrlConst.PROJECT_STAFF,
		UrlConst.PROJECT_STAFF_ADD,
		UrlConst.PROJECT_STAFF_REMOVE
})
public class ProjectServlet extends HttpServlet {
	private ProjectService service ;
	@Override
	public void init() throws ServletException {
		service = new ProjectService();
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		switch (req.getServletPath()) {
		case UrlConst.PROJECT_DASHBOARD:
			List<Project> projects = service.findAll();
			if(projects != null && !projects.isEmpty())
				req.setAttribute("projects", projects);
			getDashboard(req,resp);
			break;
		case UrlConst.PROJECT_MANAGE:
			
			break;
		case UrlConst.PROJECT_ADD:
			List<User> users = service.findAllUser();
			if( users != null && !users.isEmpty() )
				req.setAttribute("users", users);
			getProjectAdd(req,resp);
			break;
		case UrlConst.PROJECT_UPDATE:
			int projectId = Integer.parseInt(req.getParameter("id"));
			List<Project> project = service.findById(projectId);
			if(project != null && !project.isEmpty())
				req.setAttribute("project", project);
			getProjectUpdate(req,resp);
			break;
		case UrlConst.PROJECT_DELETE:
			int deleteId = Integer.parseInt(req.getParameter("id"));
			service.delete(deleteId);
			resp.sendRedirect(req.getContextPath()+UrlConst.PROJECT_DASHBOARD);
			break;
		case UrlConst.PROJECT_STAFF:
			List<ProjectUser> projectUser = service.findProjectUser();
				if(projectUser != null && !projectUser.isEmpty())
					req.setAttribute("projects", projectUser);
			getProjectStaff(req,resp);
			break;
		case UrlConst.PROJECT_STAFF_ADD:
			List<Project> projectStaff = service.findAll();
			List<User> userStaff = service.findAllUser();
			if(projectStaff != null && !projectStaff.isEmpty() )
				req.setAttribute("projects", projectStaff);
			if(userStaff != null && !userStaff.isEmpty())
				req.setAttribute("users", userStaff); 
			getProjectStaffAdd(req,resp);
			break;
		case UrlConst.PROJECT_STAFF_REMOVE:
			int userStaffId = Integer.parseInt(req.getParameter("user_id"));
			int projectStaffId = Integer.parseInt(req.getParameter("project_id"));
			service.deleteProjectStaff(userStaffId, projectStaffId);
			resp.sendRedirect(req.getContextPath()+UrlConst.PROJECT_STAFF);
			break;
		default:
			
			break;
		}
	}
	
	private void getProjectStaffAdd(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(JspConst.PROJECT_STAFF_ADD).forward(req, resp);
	}
	private void getProjectStaff(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.getRequestDispatcher(JspConst.PROJECT_STAFF).forward(req, resp);
	}
	private void getProjectUpdate(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(JspConst.PROJECT_UPDATE).forward(req, resp);
	}
	
	private void getProjectAdd(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(JspConst.PROJECT_ADD).forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		switch (req.getServletPath()) {
		case UrlConst.PROJECT_DASHBOARD:
			getDashboard(req,resp);
			break;
		case UrlConst.PROJECT_MANAGE:
			
			break;
		case UrlConst.PROJECT_ADD:
			postProjectAdd(req,resp);
			break;
		case UrlConst.PROJECT_UPDATE:
			postProjectUpdate(req,resp);
			break;
		case UrlConst.PROJECT_DELETE:
			
			break;
		case UrlConst.PROJECT_STAFF:
			
			break;
		case UrlConst.PROJECT_STAFF_ADD:
			postProjectStaffAdd(req, resp);
			break;
		case UrlConst.PROJECT_STAFF_REMOVE:
			
			break;
		default:
			
			break;
		}
	}

	private void postProjectStaffAdd(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		ProjectStaffCreateDto dto = extractProjectCreateFromReq(req);
		service.addProjectStaff(dto);
		resp.sendRedirect(req.getContextPath()+UrlConst.PROJECT_STAFF);
	}
	private ProjectStaffCreateDto extractProjectCreateFromReq(HttpServletRequest req) {
		int projectId = Integer.parseInt(req.getParameter("project"));
		String description = req.getParameter("description");
		String join_date = req.getParameter("join_date");
		int userId = Integer.parseInt(req.getParameter("user_id"));
		return new ProjectStaffCreateDto(projectId, userId, join_date, description);
	}
	private void postProjectUpdate(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		ProjectUpdateDto dto = extractProjectUpdateFromReq(req);
		service.update(dto);
		resp.sendRedirect(req.getContextPath()+UrlConst.PROJECT_DASHBOARD);
	}
	
	private ProjectUpdateDto extractProjectUpdateFromReq(HttpServletRequest req) {
		int id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		String desciption = req.getParameter("description");
		String start_date = req.getParameter("start_date");
		String end_date = req.getParameter("end_date");
		
		return new ProjectUpdateDto(id, name, desciption, start_date, end_date);
	}
	
	private void postProjectAdd(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		ProjectCreateDto dto = extractProjectAddFromDto(req);
		service.add(dto);
		resp.sendRedirect(req.getContextPath()+UrlConst.PROJECT_DASHBOARD);
	}

	private ProjectCreateDto extractProjectAddFromDto(HttpServletRequest req) {
		String name = req.getParameter("name");
		String description = req.getParameter("description");
		String start_date = req.getParameter("start_date");
		String end_date = req.getParameter("end_date");
		int owner = Integer.parseInt(req.getParameter("user_id"));
		
		return new ProjectCreateDto(owner, name, description, start_date, end_date);
	}
	private void getDashboard(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(JspConst.PROJECT_DASHBOARD)
			.forward(req, resp);
	}
}

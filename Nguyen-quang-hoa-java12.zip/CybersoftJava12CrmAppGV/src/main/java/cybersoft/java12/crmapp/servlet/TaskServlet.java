package cybersoft.java12.crmapp.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cybersoft.java12.crmapp.dto.TaskCreateDto;
import cybersoft.java12.crmapp.dto.TaskUpdateDto;
import cybersoft.java12.crmapp.model.Project;
import cybersoft.java12.crmapp.model.Status;
import cybersoft.java12.crmapp.model.Task;
import cybersoft.java12.crmapp.model.User;
import cybersoft.java12.crmapp.service.TaskService;
import cybersoft.java12.crmapp.util.JspConst;
import cybersoft.java12.crmapp.util.ServletConst;
import cybersoft.java12.crmapp.util.UrlConst;

@WebServlet(name=ServletConst.STASK, urlPatterns = {
		UrlConst.TASK_DASHBOARD,
		UrlConst.TASK_ADD,
		UrlConst.TASK_DELETE,
		UrlConst.TASK_UPDATE,
})

public class TaskServlet extends HttpServlet {
	
	private TaskService service;
	@Override
	public void init() throws ServletException {
		service = new TaskService();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		switch (req.getServletPath()) {
			case UrlConst.TASK_DASHBOARD: 
				List<Task> tasks = service.findAll();
				if(tasks != null && !tasks.isEmpty())
					req.setAttribute("tasks", tasks);
				getTaskDashboard(req,resp);
				break;
			case UrlConst.TASK_DELETE:
				int taskId = Integer.parseInt(req.getParameter("id"));
				service.delete(taskId);
				resp.sendRedirect(req.getContextPath()+UrlConst.TASK_DASHBOARD);
				break;
			case UrlConst.TASK_UPDATE:
				List<Project> projectsUpdate =  service.findProject();
				List<User> usersUpdate = service.findUser();
				List<Status> statusUpdate = service.findStatus();
				List<TaskUpdateDto> taskUpdate ;
				if( projectsUpdate != null && !projectsUpdate.isEmpty() )
					req.setAttribute("projects", projectsUpdate);
				if(usersUpdate != null && !usersUpdate.isEmpty())
					req.setAttribute("users", usersUpdate);
				if(statusUpdate != null && !statusUpdate.isEmpty())
					req.setAttribute("status", statusUpdate);
				int taskUpdateId = Integer.parseInt(req.getParameter("id")) ;
				taskUpdate =  service.findById(taskUpdateId);
				if(taskUpdate != null && !taskUpdate.isEmpty())
					req.setAttribute("task", taskUpdate);
				getTaskUpdate(req,resp);
				break;
			case UrlConst.TASK_ADD:
				List<Project> projects =  service.findProject();
				List<User> users = service.findUser();
				List<Status> status = service.findStatus();
				
				if( projects != null && !projects.isEmpty() )
					req.setAttribute("projects", projects);
				if(users != null && !users.isEmpty())
					req.setAttribute("users", users);
				if(status != null && !status.isEmpty())
					req.setAttribute("status", status);
				getTaskAdd(req,resp);
				break;
		}
	}
	
	private void getTaskUpdate(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(JspConst.TASK_UPDATE).forward(req, resp);
	}

	private void getTaskAdd(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(JspConst.TASK_ADD).forward(req, resp);;
	}

	private void getTaskDashboard(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(JspConst.TASK_DASHBOARD).forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		switch (req.getServletPath()) {
		case UrlConst.TASK_DASHBOARD: 
			
			break;
		case UrlConst.TASK_DELETE:
			
			break;
		case UrlConst.TASK_UPDATE:
			TaskUpdateDto dtoUpdate = extractTaskUpdateFromReq(req);
			service.update(dtoUpdate);
			postTaskUpdate(req,resp);
			break;
		case UrlConst.TASK_ADD:
			TaskCreateDto dto = extractTaskFromReq(req);
			service.add(dto);
			postTaskAdd(req,resp);
			break;
		}
	}

	private TaskUpdateDto extractTaskUpdateFromReq(HttpServletRequest req) {
		String name = req.getParameter("name");
		int projectId = Integer.parseInt(req.getParameter("project_id"));
		String description = req.getParameter("description");
		String start_date = req.getParameter("start_date");
		String end_date = req.getParameter("end_date");
		int userId = Integer.parseInt(req.getParameter("user_id"));
		int statusId = Integer.parseInt(req.getParameter("status"));
		int taskId = Integer.parseInt(req.getParameter("id"));
	
		return new TaskUpdateDto(taskId, name, description, start_date, end_date, projectId, userId, statusId);
	}

	private void postTaskUpdate(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		resp.sendRedirect(req.getContextPath()+UrlConst.TASK_DASHBOARD);
	}

	private TaskCreateDto extractTaskFromReq(HttpServletRequest req) {
		String name = req.getParameter("name");
		int projectId = Integer.parseInt(req.getParameter("project_id"));
		String description = req.getParameter("description");
		String start_date = req.getParameter("start_date");
		String end_date = req.getParameter("end_date");
		int userId = Integer.parseInt(req.getParameter("user_id"));
		int statusId = Integer.parseInt(req.getParameter("status"));
		
		return new TaskCreateDto(name, description, start_date, end_date, projectId, userId, statusId);
	}

	private void postTaskAdd(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		resp.sendRedirect(req.getContextPath()+UrlConst.TASK_DASHBOARD);
	}
	
}

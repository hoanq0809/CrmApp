package cybersoft.java12.crmapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import cybersoft.java12.crmapp.dbconnection.MySqlConnection;
import cybersoft.java12.crmapp.dto.ProjectCreateDto;
import cybersoft.java12.crmapp.dto.ProjectStaffCreateDto;
import cybersoft.java12.crmapp.dto.ProjectUpdateDto;
import cybersoft.java12.crmapp.model.Project;
import cybersoft.java12.crmapp.model.ProjectUser;
import cybersoft.java12.crmapp.model.User;

public class ProjectDao {

	public List<Project> findAll() throws SQLException {
		List<Project> projects = new LinkedList<Project>();
		List<User> users = new ArrayList<User>();
		
		Connection connection = MySqlConnection.getConnection();
		String query = "SELECT p.id as id , p.name as name, p.description as description, p.start_date as start_date, "
				+ "p.end_date as end_date, u.id as user_id, u.name as user_name FROM project p , user u WHERE p.owner = u.id ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Project project = new Project();
				project.setName(resultSet.getString("name"));
				project.setDescription(resultSet.getString("description"));
				project.setStart_date(resultSet.getString("start_date"));
				project.setEnd_date(resultSet.getString("end_date"));
				project.setId(resultSet.getInt("id"));
				
				int userId = resultSet.getInt("user_id");
				User user = checkUser(users,userId);
				if(user == null) {
					user = new User();
					user.setName(resultSet.getString("user_name"));
					user.setId(resultSet.getInt("id"));
					users.add(user);
				}
				project.setOwner(user);
				projects.add(project);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return projects;
	}



	private User checkUser(List<User> users, int userId) {
		for(User user: users) 
			if(user.getId() == userId)
				return user;
		return null;
	}



	public void add(ProjectCreateDto dto) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = "INSERT INTO project(name, description, start_date, end_date,owner) VALUE (?,?,?,?,?) ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setNString(1, dto.getName());
			statement.setNString(2, dto.getDescription());
			statement.setNString(3, dto.getStart_date());
			statement.setNString(4, dto.getEnd_date());
			statement.setInt(5, dto.getOwner());
			statement.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		
	}

	public List<Project> findById(int projectId) throws SQLException {
		List<Project> projects = new ArrayList<Project>();
		Connection connection = MySqlConnection.getConnection();
		String query = " SELECT id,name, description, start_date, end_date FROM project WHERE id = ? ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, projectId);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Project project = new Project();
				project.setId( Integer.parseInt(resultSet.getString("id")));
				project.setName(resultSet.getString("name"));
				project.setDescription(resultSet.getString("description"));
				project.setStart_date(resultSet.getString("start_date"));
				project.setEnd_date(resultSet.getString("end_date"));
				
				projects.add(project);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return projects;
	}

	public void update(ProjectUpdateDto dto) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = " UPDATE project SET name = ?, description = ?, start_date = ?, end_date = ? WHERE id = ? ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setNString(1, dto.getName());
			statement.setNString(2, dto.getDescription());
			statement.setNString(3, dto.getStart_date());
			statement.setNString(4, dto.getEnd_date());
			statement.setInt(5, dto.getId());
			statement.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		
		
	}

	public void delete(int deleteId) {
		Connection connection =  MySqlConnection.getConnection();
		String query = "DELETE FROM project WHERE id = ?";
		PreparedStatement statement;
		try {
			statement = connection.prepareStatement(query);
			statement.setInt(1, deleteId);
			statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	public List<User> findAllUser() throws SQLException {
		List<User> users = new LinkedList<User>();
		
		Connection connection = MySqlConnection.getConnection();
		String query = "SELECT id, name FROM user ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				User user = new User();
				user.setName(resultSet.getString("name"));
				user.setId(resultSet.getInt("id"));
				users.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		
		return users;
		
		
	}



	public void addProjectStaff(ProjectStaffCreateDto dto) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = "INSERT INTO project_user(project_id,user_id,join_date,role_description) VALUES(?,?,?,?)";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, dto.getProjectId());
			statement.setInt(2, dto.getUserId());
			statement.setNString(3, dto.getJoin_date());
			statement.setNString(4, dto.getRole_description());
			statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		
		
	}



	public List<ProjectUser> findProjectuser() throws SQLException {
		List<ProjectUser> projectUsers = new LinkedList<ProjectUser>();
		List<User> users = new ArrayList<User>();
		List<Project> projects = new ArrayList<Project>();
		
		Connection connection = MySqlConnection.getConnection();
		String query = " SELECT pu.join_date as join_date, pu.role_description as description,  "
				+ "p.name as project_name, u.name as user_name, pu.project_id as project_id, pu.user_id as user_id "
				+ "FROM project p, project_user pu, user u WHERE pu.project_id = p.id AND pu.user_id = u.id ";
		
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				ProjectUser projectUser = new ProjectUser();
				
				projectUser.setJoin_date(resultSet.getString("join_date"));
				projectUser.setRole_description(resultSet.getString("description"));
				
				int projectId = resultSet.getInt("project_id");
				Project project = checkExistProject(projects,projectId);
				if(project == null) {
					project = new Project();
					project.setName(resultSet.getString("project_name"));
					project.setId(projectId);
					projects.add(project);
				}
				int userId = resultSet.getInt("user_id");
				User user = checkExistuser(users, userId);
				if(user == null) {
					user = new User();
					user.setName(resultSet.getString("user_name"));
					user.setId(userId);
					users.add(user);
				}
				projectUser.setUserId(user);
				projectUser.setProjectId(project);
				projectUsers.add(projectUser);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return projectUsers;
		
	}



	private User checkExistuser(List<User> users, int userId) {
		for( User user : users )
			if(user.getId() == userId)
				return user;
		return null;
	}



	private Project checkExistProject(List<Project> projects, int projectId) {
		for(Project project: projects )
			if(project.getId() == projectId)
				return project;
		return null;
	}



	public void deleteStaff(int userStaffId, int projectStaffId) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = "DELETE FROM project_user WHERE project_id = ? AND user_id = ?";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, projectStaffId);
			statement.setInt(2, userStaffId);
			statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
	
	}

}

package cybersoft.java12.crmapp.service;

import java.sql.SQLException;
import java.util.List;

import cybersoft.java12.crmapp.dao.ProjectDao;
import cybersoft.java12.crmapp.dto.ProjectCreateDto;
import cybersoft.java12.crmapp.dto.ProjectStaffCreateDto;
import cybersoft.java12.crmapp.dto.ProjectUpdateDto;
import cybersoft.java12.crmapp.model.Project;
import cybersoft.java12.crmapp.model.ProjectUser;
import cybersoft.java12.crmapp.model.User;

public class ProjectService {
	
	private ProjectDao dao;
	
	public ProjectService() {
		dao = new ProjectDao();
	}
	
	public void add(ProjectCreateDto dto) {
		try {
			dao.add(dto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<Project> findAll() {
		List<Project> projects = null;
		try {
			projects = dao.findAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return projects;
	}

	public List<Project> findById(int projectId) {
		List<Project> project = null;
		try {
			project = dao.findById(projectId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return project;
	}

	public void update(ProjectUpdateDto dto) {
		try {
			dao.update(dto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void delete(int deleteId) {
		dao.delete(deleteId);
	}

	public List<User> findAllUser() {
		List<User> users = null;
		try {
			users = dao.findAllUser();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}

	public void addProjectStaff(ProjectStaffCreateDto dto) {
		try {
			dao.addProjectStaff(dto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<ProjectUser> findProjectUser() {
		List<ProjectUser> projectUsers = null;
		try {
			projectUsers = dao.findProjectuser();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return projectUsers;
	}

	public void deleteProjectStaff(int userStaffId, int projectStaffId) {
		try {
			dao.deleteStaff(userStaffId, projectStaffId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}

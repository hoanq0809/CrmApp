package cybersoft.java12.crmapp.dto;

public class ProjectStaffCreateDto {
	private int projectId;
	private int userId;
	private String join_date;
	private String role_description;
	
	
	public ProjectStaffCreateDto(int projectId, int userId, String join_date, String role_description) {
		super();
		this.projectId = projectId;
		this.userId = userId;
		this.join_date = join_date;
		this.role_description = role_description;
	}
	
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getJoin_date() {
		return join_date;
	}
	public void setJoin_date(String join_date) {
		this.join_date = join_date;
	}
	public String getRole_description() {
		return role_description;
	}
	public void setRole_description(String role_description) {
		this.role_description = role_description;
	}
	
	
}

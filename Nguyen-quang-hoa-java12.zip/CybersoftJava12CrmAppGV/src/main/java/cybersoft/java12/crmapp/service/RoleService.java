package cybersoft.java12.crmapp.service;

import java.sql.SQLException;
import java.util.List;

import cybersoft.java12.crmapp.dao.RoleDao;
import cybersoft.java12.crmapp.dto.RoleCreateDto;
import cybersoft.java12.crmapp.dto.RoleUpdateDto;
import cybersoft.java12.crmapp.model.Role;

public class RoleService {
	private RoleDao dao = null;
	
	public RoleService() {
		dao = new RoleDao();
	}
	
	public List<Role> findAll() {
		List<Role> roles = null;
		try {
		  roles = dao.findAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return roles;
	}

	public void add(RoleCreateDto dto) {
		try {
			dao.add(dto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void delete(int roleId) {
		try {
			dao.delete(roleId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void update(RoleUpdateDto dto) {
		try {
			dao.update(dto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<Role> finById(int roleIdUpdate) {
		List<Role> role = null;
		try {
			role = dao.findById(roleIdUpdate);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return role;
	}

}

package cybersoft.java12.crmapp.util;

public class PwdUtils {
	public static final String salt = "lkjaklsdjaslkdjaslkdjsadaslkdjl";
}

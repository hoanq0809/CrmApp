package cybersoft.java12.crmapp.util;

public class ServletConst {
	// Monitor
	public static final String MONITOR 	= "monitorServlet";
	
	// Home
	public static final String HOME 	= "homeServlet";
	
	public static final String AUTH 	= "authServlet";
	
	//user
	public static final String USER     = "userServlet";
	
	//role 
	public static final String ROLE 	= "roleServlet";
	
	//task
	public static final String STASK 	= "taskServlet";
	
	//status
	public static final String STATUS   = "statusServlet";
}

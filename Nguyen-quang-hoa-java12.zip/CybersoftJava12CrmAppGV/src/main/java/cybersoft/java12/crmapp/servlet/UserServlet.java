package cybersoft.java12.crmapp.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.protobuf.Service;

import cybersoft.java12.crmapp.dto.UserCreateDto;
import cybersoft.java12.crmapp.dto.UserUpdateDto;
import cybersoft.java12.crmapp.model.Role;
import cybersoft.java12.crmapp.model.User;
import cybersoft.java12.crmapp.service.UserService;
import cybersoft.java12.crmapp.util.JspConst;
import cybersoft.java12.crmapp.util.ServletConst;
import cybersoft.java12.crmapp.util.UrlConst;

@WebServlet(name= ServletConst.USER, urlPatterns = {
		UrlConst.USER_ADD,
		UrlConst.USER_DASHBOARD,
		UrlConst.USER_DELETE,
		UrlConst.USER_UPDATE,
		UrlConst.USER_PROFILE
})
public class UserServlet extends HttpServlet {
	private UserService service;
	
	@Override
	public void init() throws ServletException {
		service = new UserService();
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		UserService service = new UserService();
		switch(req.getServletPath()) {
		case UrlConst.USER_DASHBOARD:
			List<User> users = service.findAll();
			if( users != null && !users.isEmpty() )
				req.setAttribute("users", users);
			getUserDashBoard(req,resp);
			break;
		case UrlConst.USER_ADD:
			List<Role> roles = service.findRole();
			if( roles != null && !roles.isEmpty() )
				req.setAttribute("roles", roles);
			getUserAdd(req,resp);
			break;
		case UrlConst.USER_UPDATE:
			int userId = Integer.parseInt(req.getParameter("id"));
			List<User> user = service.getUserById(userId);
			if( user != null && !user.isEmpty() )
				req.setAttribute("user", user);
			getUserUpdate(req, resp);
			break;
		case UrlConst.USER_DELETE:
			int id = Integer.parseInt(req.getParameter("id"));
			service.deleteById(id);
			resp.sendRedirect(req.getContextPath()+UrlConst.USER_DASHBOARD);
			break;
		case UrlConst.USER_PROFILE:
			
			break;
			
		}
		
	}

	private void getUserUpdate(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(JspConst.USER_UPDATE).forward(req, resp);
		
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		switch(req.getServletPath()) {
		case UrlConst.USER_DASHBOARD:
		
			break;
		case UrlConst.USER_ADD:
			try {
				postUserAdd(req,resp);
			} catch (IOException | SQLException e) {
				e.printStackTrace();
			}
			break;
		case UrlConst.USER_UPDATE:
			postUserUpdate(req, resp);
			break;
		case UrlConst.USER_DELETE:
			
			break;
		case UrlConst.USER_PROFILE:
			
			break;
			
		}
	}
	
	private void postUserUpdate(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		UserUpdateDto dto = extractDtoFromReqUpdate(req);
		
		service.update(dto);
		resp.sendRedirect(req.getContextPath()+UrlConst.USER_DASHBOARD);
	}
	private UserUpdateDto extractDtoFromReqUpdate(HttpServletRequest req) {
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String phone = req.getParameter("phone");
		String address = req.getParameter("address");
		String name = req.getParameter("name");
		int roleId = Integer.parseInt(req.getParameter("role"));
		int id = Integer.parseInt(req.getParameter("user_id"));
		
		return new UserUpdateDto(id, email, password, name, address, phone, roleId);
	}
	private void postUserAdd(HttpServletRequest req, HttpServletResponse resp) throws IOException, SQLException {
		
		UserCreateDto dto = extractDtoFromReq(req) ;
		
		service.add(dto);
		resp.sendRedirect(req.getContextPath()+UrlConst.USER_DASHBOARD);
	}
	
	private UserCreateDto extractDtoFromReq(HttpServletRequest req) {
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String phone = req.getParameter("phone");
		String address = req.getParameter("address");
		String name = req.getParameter("name");
		int roleId = Integer.parseInt(req.getParameter("role"));
		
		return new UserCreateDto(name, password, address, phone, roleId, email);
	}
	
	private void getUserAdd(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(JspConst.USER_ADD).forward(req, resp);
		
	}

	private void getUserDashBoard(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(JspConst.USER_DASHBOARD).forward(req, resp);
	}
}

package cybersoft.java12.crmapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.mysql.cj.x.protobuf.MysqlxPrepare.Prepare;

import cybersoft.java12.crmapp.dbconnection.MySqlConnection;
import cybersoft.java12.crmapp.dto.TaskCreateDto;
import cybersoft.java12.crmapp.dto.TaskUpdateDto;
import cybersoft.java12.crmapp.model.Project;
import cybersoft.java12.crmapp.model.Status;
import cybersoft.java12.crmapp.model.Task;
import cybersoft.java12.crmapp.model.User;

public class TaskDao {

	public List<Project> findProjects() throws SQLException {
		List<Project> projects = new LinkedList<Project>();
		
		Connection connection = MySqlConnection.getConnection();
		String query = " SELECT id , name FROM project ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Project project = new Project();
				
				project.setName(resultSet.getString("name"));
				project.setId(resultSet.getInt("id"));
				
				projects.add(project);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return projects;
	}

	public List<User> findUser() throws SQLException {
		List<User> users = new LinkedList<User>();
		
		Connection connection = MySqlConnection.getConnection();
		String query = "SELECT name,id FROM user";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				User user = new User();
				user.setName(resultSet.getString("name"));
				user.setId(resultSet.getInt("id"));
				
				users.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		
		return users;
	}

	public void add(TaskCreateDto dto) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = " INSERT INTO task(name,description,start_date,end_date,project_id,user_id,status_id) VALUES(?,?,?,?,?,?,?) ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setNString(1, dto.getName());
			statement.setNString(2, dto.getDescription());
			statement.setNString(3, dto.getStart_date());
			statement.setNString(4, dto.getEnd_date());
			statement.setInt(5, dto.getProject());
			statement.setInt(6, dto.getUser());
			statement.setInt(7, dto.getStatus());
			statement.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		
	}

	public List<Status> findStatus() throws SQLException {
		List<Status> statuses = new ArrayList<Status>();
		
		Connection connection = MySqlConnection.getConnection();
		String query = "SELECT id, name, description FROM status";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Status status = new Status();
				status.setId(resultSet.getInt("id"));
				status.setName(resultSet.getString("name"));
				status.setDescription(resultSet.getString("description"));
				statuses.add(status);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return statuses;
	}

	public List<Task> findAll() throws SQLException {
		List<Task> tasks = new LinkedList<Task>();
		List<User> users = new ArrayList<User>();
		List<Project> projects = new ArrayList<Project>();
		List<Status> statuses = new ArrayList<Status>();
		
		Connection connection = MySqlConnection.getConnection();
		String query = " SELECT t.name as task_name,t.description as task_description, t.start_date as start_date, t.end_date as end_date,"
				+ "t.id as task_id, t.user_id as user_id, t.project_id as project_id, t.status_id as status_id, u.name as user_name,"
				+ " p.name as project_name, s.name as status_name "
				+ "FROM task t,user u, project p, status s WHERE t.user_id = u.id AND t.project_id = p.id AND t.status_id = s.id ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Task task = new Task();
				task.setName(resultSet.getString("task_name"));
				task.setDescription(resultSet.getString("task_description"));
				task.setStart_date(resultSet.getString("start_date"));
				task.setEnd_date(resultSet.getString("end_date"));
				task.setId(resultSet.getInt("task_id"));
				
				int userId = resultSet.getInt("user_id");
				User user = checkExistUser(users, userId);
				if( user == null ) {
					user = new User();
					user.setName(resultSet.getString("user_name"));
					user.setId(userId);
					users.add(user);
				}
				int projectId = resultSet.getInt("project_id");
				Project project = checkExistProject(projects, projectId);
				if( project == null ) {
					project = new Project();
					project.setName(resultSet.getString("project_name"));
					project.setId(projectId);
					projects.add(project);
				}
				int statusId = resultSet.getInt("status_id");
				Status status = checkExistTatus(statuses, statusId);
				if( status == null ) {
					status = new Status();
					status.setName(resultSet.getString("status_name"));
					status.setId(statusId);
				}
				task.setUser(user);
				task.setProject(project);
				task.setStatus(status);
				tasks.add(task);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return tasks;
	}

	private Status checkExistTatus(List<Status> statuses, int statusId) {
		for(Status status : statuses)
			if(status.getId() == statusId)
				return status;
		return null;
	}

	private Project checkExistProject(List<Project> projects, int projectId) {
		for(Project project : projects)
			if(project.getId() == projectId)
				return project;
		return null;
	}

	private User checkExistUser(List<User> users, int userId) {
		for(User user : users)
			if(user.getId() == userId)
				return user;
		return null;
	}

	public void delete(int taskId) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = "DELETE FROM task WHERE id = ? ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, taskId);
			statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		
	}

	public List<TaskUpdateDto> findById(int taskUpdateId) throws SQLException {
		List<TaskUpdateDto> dtos = new ArrayList<TaskUpdateDto>();
		
		Connection connection = MySqlConnection.getConnection();
		String query = " SELECT name, description, start_date, end_date, user_id, project_id, status_id FROM task WHERE id = ?  ";
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, taskUpdateId);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				
				String name = resultSet.getString("name");
				String description = resultSet.getString("description");
				String start_date = resultSet.getString("start_date");
				String end_date = resultSet.getString("end_date");
				int user_id = resultSet.getInt("user_id");
				int project_id = resultSet.getInt("project_id");
				int status_id = resultSet.getInt("status_id");
	
				TaskUpdateDto dto = new TaskUpdateDto(taskUpdateId, name, description, start_date, end_date, project_id, user_id, status_id);
				dtos.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		return dtos;
	}

	public void update(TaskUpdateDto dtoUpdate) throws SQLException {
		Connection connection = MySqlConnection.getConnection();
		String query = " Update task SET name = ?, description = ?, start_date = ?, end_date = ?, project_id = ?, user_id = ?, status_id = ? WHERE id = ? ";
		
		try {
			PreparedStatement  statement = connection.prepareStatement(query);
			statement.setNString(1, dtoUpdate.getName());
			statement.setNString(2, dtoUpdate.getDescription());
			statement.setNString(3, dtoUpdate.getStart_date());
			statement.setNString(4, dtoUpdate.getEnd_date());
			statement.setInt(5, dtoUpdate.getProject());
			statement.setInt(6, dtoUpdate.getUser());
			statement.setInt(7, dtoUpdate.getStatus());
			statement.setInt(8, dtoUpdate.getId());
			statement.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connection.close();
		}
		
	}

}

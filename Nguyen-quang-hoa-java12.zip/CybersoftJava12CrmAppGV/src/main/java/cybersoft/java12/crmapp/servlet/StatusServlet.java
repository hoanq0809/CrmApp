package cybersoft.java12.crmapp.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cybersoft.java12.crmapp.dto.StatusCreateDto;
import cybersoft.java12.crmapp.dto.StatusUpdateDto;
import cybersoft.java12.crmapp.model.Status;
import cybersoft.java12.crmapp.service.StatusService;
import cybersoft.java12.crmapp.util.JspConst;
import cybersoft.java12.crmapp.util.ServletConst;
import cybersoft.java12.crmapp.util.UrlConst;

@WebServlet(name=ServletConst.STATUS, urlPatterns = {
		 UrlConst.STATUS_ADD,
		 UrlConst.STATUS_DASHBOARD,
		 UrlConst.STATUS_DELETE,
		 UrlConst.STATUS_UPDATE,
})


public class StatusServlet extends HttpServlet {
	private StatusService service;
	@Override
	public void init() throws ServletException {
		service = new StatusService();
	}
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		switch (req.getServletPath()) {
			case UrlConst.STATUS_DASHBOARD: 
				List<Status> status = service.findAll();
				if(status != null && !status.isEmpty())
					req.setAttribute("statuses", status);
				getStatusDashBoard(req,resp);
				break;
			case UrlConst.STATUS_UPDATE:
				int statusIdUpdate = Integer.parseInt(req.getParameter("id"));
				List<StatusUpdateDto> statusUpdate = service.findById(statusIdUpdate);
				if(statusUpdate != null && !statusUpdate.isEmpty())
					req.setAttribute("status", statusUpdate);
				req.getRequestDispatcher(JspConst.STATUS_UPDATE).forward(req, resp);
				break;
			case UrlConst.STATUS_DELETE:
				int statusId = Integer.parseInt(req.getParameter("id"));
				service.delete(statusId);
				resp.sendRedirect(req.getContextPath()+UrlConst.STATUS_DASHBOARD);
				break;
			case UrlConst.STATUS_ADD:
				req.getRequestDispatcher(JspConst.STATUS_ADD).forward(req, resp);
				break;
		}
	}
	
	private void getStatusDashBoard(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher(JspConst.STATUS_DASHBOARD).forward(req, resp);
	}


	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		switch (req.getServletPath()) {
		case UrlConst.STATUS_DASHBOARD: 
		
			break;
		case UrlConst.STATUS_UPDATE:
			StatusUpdateDto dtoUpdate = extractStatusUpdateFromReq(req);
			service.update(dtoUpdate);
			postStatusUpdate(req,resp);
			break;
		case UrlConst.STATUS_DELETE:
			
			break;
		case UrlConst.STATUS_ADD:
			StatusCreateDto dto = extractStatusFromReq(req);
			service.add(dto);
			postStatusAdd(req,resp);
			break;
		}
	}


	private StatusUpdateDto extractStatusUpdateFromReq(HttpServletRequest req) {
		int id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		String description = req.getParameter("description");
		return new StatusUpdateDto(id, name, description);
	}


	private void postStatusUpdate(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		resp.sendRedirect(req.getContextPath()+UrlConst.STATUS_DASHBOARD);
		
	}


	private StatusCreateDto extractStatusFromReq(HttpServletRequest req) {
		String name = req.getParameter("name");
		String description = req.getParameter("description");
		
		return new StatusCreateDto(name, description);
	}


	private void postStatusAdd(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		resp.sendRedirect(req.getContextPath()+UrlConst.STATUS_DASHBOARD);
	}
}
